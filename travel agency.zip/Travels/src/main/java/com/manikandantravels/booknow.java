package com.manikandantravels;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class booknow
 */
@WebServlet("/booknow")
public class booknow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public booknow() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	
	{

		
		String uname =request.getParameter("name");
		String uage =request.getParameter("age");
		String utripdate =request.getParameter("tripdate");
		String upackage =request.getParameter("package");
		String uquantity =request.getParameter("quantity");
		String upickuptime =request.getParameter("pickuptime");
		String ucoachtype=request.getParameter("coachtype");
		String uphone =request.getParameter("phone");
		String ucardnumber =request.getParameter("cardnumber");
		String ucvv =request.getParameter("cvv");
		String uaddress =request.getParameter("address");
		RequestDispatcher dispatcher = null;
		HttpSession session =request.getSession();
		
	
	


			try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/travels","root","0000");
	PreparedStatement pst = con.prepareStatement("insert into users(uname,uage,utripdate,upackage,uquantity,upickuptime,ucoachtype,uphone,ucardnumber,ucvv,uaddress) values (?,?,?,?,?,?,?,?,?,?,?)");
	
	pst.setString(1, uname);
	pst.setString(2, uage);
	pst.setString(3, utripdate);
	pst.setString(4, upackage);
	pst.setString(5, uquantity);
	pst.setString(6, upickuptime);
	pst.setString(7, ucoachtype);
	pst.setString(8, uphone);
	pst.setString(9, ucardnumber);
	pst.setString(10, ucvv);
	pst.setString(11, uaddress);
	
	dispatcher.forward(request, response);
	
}
catch (Exception e)
{
	e.printStackTrace();
}}}
